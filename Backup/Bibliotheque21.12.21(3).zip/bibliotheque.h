#ifndef BIBLIOTHEQUE_H
#define BIBLIOTHEQUE_H
//#include "image.h"

#include <experimental/filesystem>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm> 
//#include <bits/stdc++.h>
#include <jsoncpp/json/value.h>
#include <jsoncpp/json/json.h>
#include "rapidjson/document.h"
#include "rapidjson/writer.h"


using namespace rapidjson ;
using namespace std ;


class Bibliotheque{
    private :      
        Json::Value _bibliotheque ;                     // Objet de type Json

    public :
        /*Constructeurs*/
        Bibliotheque() ;                                // Constructeur vide 
        Bibliotheque(string nom) ;                      // Constructeur avec le nom de la bibliotheque donnee par l'utilisateur
        Bibliotheque(const Json::Value bibliotheque) ;  // Constructeur avec un objet Json
        /*Getter*/
        Json::Value getBilbiotheque() const ;
        /*Setter*/
        void setBilbiotheque(const Json::Value bibliotheque) ;

        /*Methodes*/
        // Afficher la liste des descripteurs
        void AfficherDescripteur(const Bibliotheque) ;
        // Affichage le cout d'une image
        void AfficherCout(const Bibliotheque) ;
        //Construire et afficher une sous-liste
        void ConstruireAfficherSousListe(const Bibliotheque) ;
        //Trier la bibliotheque suivant une critere
        void Trier(const Bibliotheque) ;
        /*
        //Ajouter une image dans la bibliotheque
        void AjouterImage(Image images) ;
        //Supprimer une image de la bibliotheque
        void SupprimerImage(Image images) ;*/
        //Sauvegarder une bibliotheque
        void Sauvegarder(const Bibliotheque) ;
};

#endif // BIBLIOTHEQUE_H
