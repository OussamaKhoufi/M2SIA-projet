#include "bibliotheque.h"
#include <bits/stdc++.h>

int main (void){

    string nom = "bibliotheque";
    Bibliotheque A ;
    cout << "Afficher tous les descripteurs" << endl << endl ;
    A.AfficherDescripteur(A) ; 
    cout << "Afficher le cout suivant le numero choisi" << endl << endl ;
    A.AfficherCout(A) ;
    cout << "Construire et afficher une sous-liste" << endl ;
    A.ConstruireAfficherSousListe(A) ;
    cout << "Trier la bibliotheque suivant une critere choisie" << endl ;
    A.Trier(A) ;


    /*int c, k ;
    vector<int> indice_trie ;
    vector<string> cout_non_trie {"d","dfef","edffg","wxsc","wvhr kjkj","hj","a","12","a12"} ;
    vector<string> cout_trie ;
    int nbImages = cout_non_trie.size() ;
    cout << "nbImages = " << nbImages << endl ;
    double condition ;

    cout << endl << *find(cout_non_trie.begin(), cout_non_trie.end(), "a") << endl ;
    cout_trie = cout_non_trie ;                                     // Initialiser le vecteur des couts tries
    sort(cout_trie.begin(), cout_trie.end(), greater<string>()) ;   // Trier les couts dan l'ordre decroissant
    cout << endl << endl ;
    for (c = 0 ; c < nbImages ; c++){
        cout << cout_trie[c] << endl ;
    }

    
    for (c = 0 ; c < nbImages ; c++){
        //cout << "c = " << c << endl << endl ;
        for (k = 0 ; k < nbImages ; k++){
            //cout << "k = " << k << endl << endl ;
            if ((cout_trie[c] == cout_non_trie[k])){
                //cout << "cout_trie[c] = " << cout_trie[c] << endl ;
                //cout << "cout_non_trie[k] = " << cout_non_trie[k] << endl ;
                if (c > 0){
                    condition = *find(indice_trie.begin(), indice_trie.end(), k) ;
                }else{
                    condition = k + 1 ;
                }
                //cout << "condition = " << condition << endl ;
                if (condition != k){                                   
                    indice_trie.push_back(k) ;
                }
            }
        }
    }
    cout << endl ;
    for (c = 0 ; c < nbImages ; c++){
        cout << indice_trie[c] << endl ;
    }*/


    /*Document bibliotheque ;

    bibliotheque.Parse("bibliotheque.json") ;
    assert(bibliotheque.HasMember("nbImages")) ;
    assert(bibliotheque["nbImages"].IsInt());
    //printf("%d\n", (int)bibliotheque["nbImages"]) ;
    cout << bibliotheque["images"][0]["source"].GetString() << endl ;*/

    return 0 ;
}


// jq ".images[].source" bibliotheque.json
// g++ -Wall  bibliotheque.h
// g++ -Wall -c  bibliotheque.cpp -o -bibliotheque.o
// g++ -Wall  main.cpp bibliotheque.o -ljsoncpp