#include "bibliotheque.h"

/*Constructeur vide*/
Bibliotheque::Bibliotheque(){
    Json::Reader reader ;
    ifstream bibliotheque_file("./bibliotheque.json", ios::in) ;    // Charger le contenu du fichier json 
    reader.parse(bibliotheque_file, _bibliotheque) ;                // Importer le contenu a l'objet Json
}

/*Constructeur avec le nom de la bibliotheque donnee par l'utilisateur*/
Bibliotheque::Bibliotheque(string nom){
    //
    if (nom.length() < 6){
        nom += ".json" ;
    }else{
        if(nom.find(".json", nom.length()-5) != nom.length()-5){
            nom += ".json" ;
        }
    }
    Json::Reader reader ;

    ifstream bibliotheque_file(nom, ios::in) ;  
    reader.parse(bibliotheque_file, _bibliotheque) ;    
    cout << _bibliotheque["nbImages"] << endl ;
}

/*Constructeur avec un objet Json*/
Bibliotheque::Bibliotheque(const Json::Value bibliotheque){
    setBilbiotheque(bibliotheque) ;
}

/*Getter*/
Json::Value Bibliotheque::getBilbiotheque() const{
    return _bibliotheque ;
}
/*Setter*/
void Bibliotheque::setBilbiotheque(const Json::Value bibliotheque){
    _bibliotheque = bibliotheque ;
}

/*Afficher la liste des descripteurs*/
void Bibliotheque::AfficherDescripteur(const Bibliotheque){
    /*Declaration des variables*/
    Json::Value biblio = getBilbiotheque() ;        // Objet Json
    int nbImages = biblio["nbImages"].asInt() ;     // Nombre d'images existantes dans la bibliotheque
    int c, k ;                                      // Indices
    k = 0 ;
    for (c = 0 ; c < nbImages ; c++){
        cout << "Image " << k++ << endl ;
        cout << "Source : " << biblio["images"][c]["source"].asString() << endl ;
        cout << "Titre : " << biblio["images"][c]["titre"].asString() << endl ;
        cout << "Numero : " << biblio["images"][c]["numero"].asInt() << endl ;
        cout << "Cout : " << biblio["images"][c]["cout"].asDouble() << "€" << endl ;
        cout << "Permission : " << biblio["images"][c]["acces"].asString() << endl ;
        cout << "Date d'ajout : " << biblio["images"][c]["dateAjout"].asString() << endl ;
        cout << "Date de creation : " << biblio["images"][c]["dateCreation"].asString() << endl << endl ;  
    }
}

/*Affichage le cout d'une image*/
void Bibliotheque::AfficherCout(const Bibliotheque){
    /*Declaration des variables*/
    int c ;                                         // Indice
    int numero_saisie ;                             // Numero saisi par l'utilisateur
    bool exist = false ;                            // Verificaiton de l'existance du numero saisi
    bool continu = true ;                           // Condition d'arret
    char decision ;                                 // Decision (Y/N)
    Json::Value biblio = getBilbiotheque() ;        // Objet Json
    int nbImages = biblio["nbImages"].asInt() ;     // Nombre d'images existantes dans la bibliotheque
     
    do{
        // Saisie du numero souhaite
        cout << "Veuillez donner le numero de l'image : " << endl ;
        cin >> numero_saisie ; 
        // Verification de l'existance du numero saisi dans la bibliotheque
        for (c = 0 ; c < nbImages ; c++){
            // Si le numero existe
            if (numero_saisie == biblio["images"][c]["numero"].asInt()){
                exist = true ;
                // Affichage le cout correspondant
                cout << "Cout de l'image " << numero_saisie << " : " << biblio["images"][c]["cout"].asDouble() << "€" << endl ;
                break ;
            }
        }
        // Si le numero n'existe pas
        if (exist == false){
            cout << "Le numero choisi n'existe pas." << endl ;
        }
        // Choisir un autre numero
        cout << "Voulez-vous saisir un autre numero ? [Y/N]" << endl ;
        do{
            cin >> decision ;
            if ((decision != 'Y') && (decision != 'N')){
                cout << "Choix invalide. Veuillez saisir 'Y' ou 'N'." << endl ;
            }
        } while((decision != 'Y') && (decision != 'N')) ;
        // Decider de continuer/arreter la boucle
        if (decision == 'N'){
            continu = false ;
        }
    }while(continu == true) ;
}

/*Construire et afficher une sous-liste*/
void Bibliotheque::ConstruireAfficherSousListe(const Bibliotheque){
    /*Declaration des variables*/
    Json::Value biblio = getBilbiotheque() ;        // Objet Json
    int nbImages = biblio["nbImages"].asInt() ;     // Nombre d'images existantes dans la bibliotheque
    int choix ;                                     // Choix du critere
    int choix_plage ;                               // Choix de la plage de cout
    int c ;                                         // Indice
    int compteur = 0 ;                              // Compteur du nombre d'images choisies par critere
    string choix_source ;                           // Choix de la source
    bool choix_source_verification = false ;        // Verification du choix de la source saisie par l'utilisateur
    bool continu = true ;                           // Condition d'arret
    char decision ;                                 // Choix (Y/N)
    double plage_min, plage_max ;                   // Plage de cout personalisee

    cout << "Veuillez choisir un critere : " << endl ;
    cout << "1. Cout" << endl << "2. Source" << endl << endl ;
    do{
        // Saisie le choix
        cin >> choix ;
        // Validation du choix
        if ((choix != 1) && (choix != 2)){
            cout << "Choix invalide. Veuillez saisir '1' ou '2'." << endl ;
        }
    }while((choix != 1) && (choix != 2)) ;
    switch (choix){
        // Critere choisi : Cout
        case 1 :
            cout << "Veuillez choisir une plage de cout :" << endl ;
            cout << "1. Gratuit" << endl << "2. Cout ≤ 99,99 €" << endl << "3. 100 ≤ Cout ≤ 999,99 €" << endl << "4. Cout > 1000 €" << endl << "5. Plage personnalisee" << endl ;
            do{
                cin >> choix_plage ;
                if ((choix_plage != 1) && (choix_plage != 2) && (choix_plage != 3) && (choix_plage != 4) && (choix_plage != 5)){
                    cout << "Choix invalide. Veuillez saisir '1', '2', '3', '4' ou '5'." << endl ;
                }
            }while((choix_plage != 1) && (choix_plage != 2) && (choix_plage != 3) && (choix_plage != 4) && (choix_plage != 5)) ;  
            switch (choix_plage){
                // Sous-critere : Cout gratuit
                case 1 :
                    // Affichage conditionnelle
                    for (c = 0 ; c < nbImages ; c++){
                        if (biblio["images"][c]["cout"].asDouble() == 0.0){
                            cout << "Source : " << biblio["images"][c]["source"].asString() << endl ;
                            cout << "Titre : " << biblio["images"][c]["titre"].asString() << endl ;
                            cout << "Numero : " << biblio["images"][c]["numero"].asInt() << endl ;
                            cout << "Permission : " << biblio["images"][c]["acces"].asString() << endl ;
                            cout << "Date d'ajout : " << biblio["images"][c]["dateAjout"].asString() << endl ;
                            cout << "Date de creation : " << biblio["images"][c]["dateCreation"].asString() << endl << endl ; 
                            compteur++ ;
                        }
                    }
                    cout << "Il y a " << compteur << " images gratuites." << endl << endl ;
                    break ;
                // Sous-critere : Cout ≤ 99,99 €
                case 2 :
                    // Affichage conditionnelle
                    for (c = 0 ; c < nbImages ; c++){
                        if (biblio["images"][c]["cout"].asDouble() <= 99.99){
                            cout << "Source : " << biblio["images"][c]["source"].asString() << endl ;
                            cout << "Titre : " << biblio["images"][c]["titre"].asString() << endl ;
                            cout << "Numero : " << biblio["images"][c]["numero"].asInt() << endl ;
                            cout << "Permission : " << biblio["images"][c]["acces"].asString() << endl ;
                            cout << "Date d'ajout : " << biblio["images"][c]["dateAjout"].asString() << endl ;
                            cout << "Date de creation : " << biblio["images"][c]["dateCreation"].asString() << endl << endl ; 
                            compteur++ ;
                        }
                    }
                    cout << "Il y a " << compteur << " images ayant le cout ≤ 99,99 €" << endl << endl ;
                    break ;  
                // Sous-critere : 100 ≤ Cout ≤ 999,99 €
                case 3 :
                    // Affichage conditionnelle
                    for (c = 0 ; c < nbImages ; c++){
                        if ((biblio["images"][c]["cout"].asDouble() >= 100) && (biblio["images"][c]["cout"].asDouble() <= 999.99)){
                            cout << "Source : " << biblio["images"][c]["source"].asString() << endl ;
                            cout << "Titre : " << biblio["images"][c]["titre"].asString() << endl ;
                            cout << "Numero : " << biblio["images"][c]["numero"].asInt() << endl ;
                            cout << "Permission : " << biblio["images"][c]["acces"].asString() << endl ;
                            cout << "Date d'ajout : " << biblio["images"][c]["dateAjout"].asString() << endl ;
                            cout << "Date de creation : " << biblio["images"][c]["dateCreation"].asString() << endl << endl ; 
                            compteur++ ;
                        }
                    }
                    cout << "Il y a " << compteur << " images ayant le cout entre 100 et 999,99 €" << endl << endl ;
                    break ;  
                // Sous-critere : Cout > 1000 €
                case 4 :
                    // Affichage conditionnelle
                    for (c = 0 ; c < nbImages ; c++){
                        if (biblio["images"][c]["cout"].asDouble() > 1000){
                            cout << "Source : " << biblio["images"][c]["source"].asString() << endl ;
                            cout << "Titre : " << biblio["images"][c]["titre"].asString() << endl ;
                            cout << "Numero : " << biblio["images"][c]["numero"].asInt() << endl ;
                            cout << "Permission : " << biblio["images"][c]["acces"].asString() << endl ;
                            cout << "Date d'ajout : " << biblio["images"][c]["dateAjout"].asString() << endl ;
                            cout << "Date de creation : " << biblio["images"][c]["dateCreation"].asString() << endl << endl ; 
                            compteur++ ;
                        }
                    }
                    cout << "Il y a " << compteur << " images ayant le cout > 1000 €" << endl << endl ;
                    break ;  
                // Sous-critere : Plage de cout personnalisee
                case 5 :
                    /*Saisie de la plage de cout souhaitee*/
                    cout << "Veuillez saisir la plage de cout souhaitee : " << endl ; 
                    // Cout minimum
                    cout << "Min : " ;
                    do{
                        cin >> plage_min ;
                        if (plage_min < 0){
                            cout << "Veuillez choisir une valeur positive ou nulle." << endl ;
                        }
                    }while(plage_min < 0) ;
                    // Cout maximum
                    cout << "Max : " ;
                    do{
                        cin >> plage_max ;
                        if (plage_max < plage_min){
                            cout << "Veuillez choisir une valeur > " << plage_min << endl ;
                        }
                    }while(plage_max < plage_min) ;
                    // Affichage conditionnelle
                    for (c = 0 ; c < nbImages ; c++){
                        if ((biblio["images"][c]["cout"].asDouble() >= plage_min) && (biblio["images"][c]["cout"].asDouble() <= plage_max)){
                            cout << "Source : " << biblio["images"][c]["source"].asString() << endl ;
                            cout << "Titre : " << biblio["images"][c]["titre"].asString() << endl ;
                            cout << "Numero : " << biblio["images"][c]["numero"].asInt() << endl ;
                            cout << "Permission : " << biblio["images"][c]["acces"].asString() << endl ;
                            cout << "Date d'ajout : " << biblio["images"][c]["dateAjout"].asString() << endl ;
                            cout << "Date de creation : " << biblio["images"][c]["dateCreation"].asString() << endl << endl ; 
                            compteur++ ;
                        }
                    }
                    cout << "Il y a " << compteur << " images dans la plage de cout personnalisee" << endl << endl ;
                    break ;
            }
            break ;
        // Critere choisi : Source
        case 2 :
            // Saisie de la source souhaitee
            do{
                continu = true ;
                cout << "Veuillez saisir une source souhaitee :" << endl ;
                cin >> choix_source ;
                for (c = 0 ; c < nbImages ; c++){
                    if (biblio["images"][c]["source"].asString() == choix_source){
                        cout << "Titre : " << biblio["images"][c]["titre"].asString() << endl ;
                        cout << "Numero : " << biblio["images"][c]["numero"].asInt() << endl ;
                        cout << "Cout : " << biblio["images"][c]["cout"].asDouble() << "€" << endl ;
                        cout << "Permission : " << biblio["images"][c]["acces"].asString() << endl ;
                        cout << "Date d'ajout : " << biblio["images"][c]["dateAjout"].asString() << endl ;
                        cout << "Date de creation : " << biblio["images"][c]["dateCreation"].asString() << endl << endl ; 
                        compteur++ ;
                        choix_source_verification = true ;
                        continu = false ;
                    }
                }
                if(choix_source_verification == false){
                    cout << "Source invalide. Veuillez saisir une autre source. Voulez-vous continuer ? [Y/N]" << endl ;
                    do{
                        cin >> decision ;
                        if ((decision != 'Y') && (decision != 'N')){
                            cout << "Choix invalide. Veuillez saisir 'Y' ou 'N'." << endl ;
                        }
                    } while((decision != 'Y') && (decision != 'N')) ;
                    // Decider de continuer/arreter la boucle
                    if (decision == 'N'){
                        continu = false ;
                    }
                }
            }while(continu == true) ;

            cout << "Il y a " << compteur << " images correspondates a cette source." << endl << endl ;
            break ;
        default :
            break ;
    }
}

/*Trier la bibliotheque suivant une critere choisie*/
void Bibliotheque::Trier(const Bibliotheque){
    /*Declaration des variables*/
    Json::Value biblio_trie ;                               // Bibliotheque trie
    Json::Value biblio_non_trie = getBilbiotheque() ;       // Bibliotheque non triee 
    bool continu ;                                          // Choix d'affichage
    char decision ;                                         // Decision [Y/N]
    int choix ;                                             // Choix du critere pour trier la bibliotheque
    int nbImages = biblio_non_trie["nbImages"].asInt() ;    // Nombre d'images existantes dans la bibliotheque
    int c, k ;                                              // Indices
    double exist ;                                          // Condition pour verifier la redondance d'une valeur 
    vector<int> indice_trie ;                               // Vecteur des indices du tri
    Bibliotheque bibliotheque_trie ;                        // Biblioheque triee
    // Critere : Cout
    vector<double> cout_non_trie ;                          // Vecteur des couts non tries des images
    vector<double> cout_trie ;                              // Vecteur des couts tries des images
    // Critere : Titre
    vector<string> titre_non_trie ;                         // Vecteur des titres non tries des images
    vector<string> titre_trie ;                             // Vecteur des titres tries des images

    do{
        indice_trie.clear() ;                               // Remise a vide le vecteur des indices du tri
        biblio_trie.clear() ;                               // Remise a vide la bibliotheque triee
        continu = true ;         
        // Choix du critere de tri
        cout << "1. Cout dans l'ordre decroissant" << endl << "2. Titre dans l'ordre decroissant" << endl << endl ;
        do{
            // Saisie le choix
            cin >> choix ;
            // Validation du choix
            if ((choix != 1) && (choix != 2)){
                cout << "Choix invalide. Veuillez saisir '1' ou '2'." << endl ;
            }
        }while((choix != 1) && (choix != 2)) ;
        switch (choix){
            case 1 :
                cout << "Critere choisi : Cout dans l'ordre decroissant" << endl ;
                //Initialiser vecteur des couts
                for (c = 0 ; c < nbImages ; c++){
                    cout_non_trie.push_back(biblio_non_trie["images"][c]["cout"].asDouble()) ;
                }
                //Vecteur des indices du tri
                cout_trie = cout_non_trie ;                                     // Initialiser le vecteur des couts tries
                sort(cout_trie.begin(), cout_trie.end(), greater<double>()) ;   // Trier les couts dan l'ordre decroissant
                for (c = 0 ; c < nbImages ; c++){
                    for (k = 0 ; k < nbImages ; k++){
                        if ((cout_trie[c] == cout_non_trie[k])){
                            if (c > 0){
                                exist = *find(indice_trie.begin(), indice_trie.end(), k) ;
                            }else{
                                exist = k + 1 ;
                            }
                            if (exist != k){                                   
                                indice_trie.push_back(k) ;
                            }
                        }
                    }
                }
                //Tri de la bibliotheque
                biblio_trie = biblio_non_trie ;
                for (c = 0 ; c < nbImages ; c++){
                    biblio_trie["images"][c] = biblio_non_trie["images"][indice_trie[c]] ;
                }
                break ;
            case 2 :
                cout << "Critere choisi : Titre dans l'ordre decroissant" << endl ;
                //Initialiser vecteur des titres
                for (c = 0 ; c < nbImages ; c++){
                    titre_non_trie.push_back(biblio_non_trie["images"][c]["titre"].asString()) ;
                }
                //Vecteur des indices du tri
                titre_trie = titre_non_trie ;                                     // Initialiser le vecteur des couts tries
                sort(titre_trie.begin(), titre_trie.end(), greater<string>()) ;   // Trier les couts dan l'ordre decroissant
                for (c = 0 ; c < nbImages ; c++){
                    for (k = 0 ; k < nbImages ; k++){
                        if ((titre_trie[c] == titre_non_trie[k])){
                            if (c > 0){
                                exist = *find(indice_trie.begin(), indice_trie.end(), k) ;
                            }else{
                                exist = k + 1 ;
                            }
                            if (exist != k){                                   
                                indice_trie.push_back(k) ;
                            }
                        }
                    }
                }
                //Tri de la bibliotheque
                biblio_trie = biblio_non_trie ;
                for (c = 0 ; c < nbImages ; c++){
                    biblio_trie["images"][c] = biblio_non_trie["images"][indice_trie[c]] ;
                }
                break ;
            default :
                break ;
        }
        // Affichage
        bibliotheque_trie.setBilbiotheque(biblio_trie) ;
        bibliotheque_trie.AfficherDescripteur(bibliotheque_trie) ;
        // Continuer
        do{
            cout << "Voulez-vous continuer ? [Y/N]" << endl ;
            cin >> decision ;
            if ((decision != 'Y') && (decision != 'N')){
                cout << "Choix invalide. Veuillez saisir 'Y' ou 'N'." << endl ;
            }
        } while((decision != 'Y') && (decision != 'N')) ;
        // Decider de continuer/arreter la boucle
        if (decision == 'N'){
            continu = false ;
        }
    }while(continu == true) ;
}




